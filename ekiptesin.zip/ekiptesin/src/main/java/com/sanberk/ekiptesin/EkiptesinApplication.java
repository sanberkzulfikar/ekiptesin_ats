package com.sanberk.ekiptesin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EkiptesinApplication {

    public static void main(String[] args) {
        SpringApplication.run(EkiptesinApplication.class, args);
    }

}
