package exception.message;
public class Error {
    public final static String CANDIDATE_NOT_FOUND_EXCEPTION = "Candidate with id %s is not found";
}
