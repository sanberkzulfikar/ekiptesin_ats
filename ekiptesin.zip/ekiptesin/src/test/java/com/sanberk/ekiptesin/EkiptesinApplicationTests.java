package com.sanberk.ekiptesin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EkiptesinApplicationTests {

    @Test
    void contextLoads() {
    }

}
